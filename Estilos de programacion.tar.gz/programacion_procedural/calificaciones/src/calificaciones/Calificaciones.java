package calificaciones;

import java.util.*;
public class Calificaciones {
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      double nota;
      System.out.println("Introduzca una nota entre 0 y 100: ");
      nota = sc.nextDouble();
      System.out.println("La calificación del alumno es ");
      if(nota < 0 || nota > 10)
         System.out.println("Nota no válida");
      else if(nota==10)
           System.out.println("Matrícula de Honor");
      else if (nota >= 9)
           System.out.println("Sobresaliente");
      else if (nota >= 8)
           System.out.println("Notable");
      else if (nota >= 7)
           System.out.println("Bien");
      else if (nota >= 6)
           System.out.println("Suficiente");
      else
           System.out.println("Complementaria");
    }
}